from django.shortcuts import render
from django.http import HttpResponce
# Create your views here.
def homepage(request):
    return "hello welcome"

