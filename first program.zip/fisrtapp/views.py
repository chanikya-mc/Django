from django.shortcuts import render
from django.http import HttpResponse


def wish(request):
    m='<h1> hi you successfully started the application</h1>'
    return HttpResponse(m)

# Create your views here.
