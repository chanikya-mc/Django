from django.db import models

class student(models.Model):
    sno=models.IntegerField()
    name=models.CharField(max_length=20)
    sclass=models.IntegerField()
    address=models.CharField(max_length=50)
