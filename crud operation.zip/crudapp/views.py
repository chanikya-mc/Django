from django.shortcuts import render,redirect
from crudapp.models import student
from crudapp.forms import studentform

# Create your views here.
def retrivew(request):
    students=student.objects.all()
    return render(request,"crudapp/index.html",{"students":students})


def create(request):
    form=studentform()
    if request.method=="POST":
        form=studentform(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/check")
    return render(request,"crudapp/create.html",{"form":form})

def delete(request,id):
    std=student.objects.get(id=id)
    std.delete()
    return redirect("/check")

def update(request,id):
    std=student.objects.get(id=id)
    if request.method=="POST":
        form=studentform(request.POST,instance=std)
        if form.is_valid():
            form.save()
            return redirect("/check")
    return render(request,"crudapp/update.html",{"student":std})

