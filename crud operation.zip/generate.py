import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "crud1.settings")
import django
django.setup()

from crudapp.models import student
from faker import Faker
from random import *

faker = Faker()

def generate_students(n):
    for i in range(n):
        fsno = randint(4, 50)
        fname = faker.name()
        fclass = randint(1, 15)
        faddress = faker.city()
        stud_record=student.objects.get_or_create(sno=fsno, name=fname, sclass=fclass, address=faddress)

# Example usage:
# generate_students(10)  # Generate 10 fake student records
