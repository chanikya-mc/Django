from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def add(req):
    a="love "
    b="chanikya"
    c=a+b
    return HttpResponse(c)
def sub(req):
    return HttpResponse(" i love you L")
