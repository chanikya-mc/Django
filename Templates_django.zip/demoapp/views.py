from django.shortcuts import render
import datetime
# Create your views here.
def display(req):
    mass="hi"
    date=datetime.datetime.now()
    hour=int(date.strftime("%H"))
    if hour<12:
        mass+="good morning"
    else:
        mass+="good evening"

    name="chanikya"
    date_dic={'date_dic':date,'myname':name,"greating":mass}
    return render(req,"demoapp/abc.html",context=date_dic)