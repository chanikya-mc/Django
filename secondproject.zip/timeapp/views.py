from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
import datetime
def time(re):
    td=datetime.datetime.now()
    return HttpResponse("<h2> current time is :" +str(td)+"</h2>")