from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def mg(request):
    return HttpResponse('<h1> good morning</h1>')
def kcpd(request):
    return HttpResponse('<h1> heyy bro whats app</h1>')
def kmpd(request):
    return HttpResponse('<h1>this is a good day</h1>')
