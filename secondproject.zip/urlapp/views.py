from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def one(re):
    return HttpResponse("hello this is fro separate url one")
def two(re):
    return HttpResponse("hello this is fro separate url two")
def three(re):
    return HttpResponse("hello this is fro separate url three")
def four(re):
    return HttpResponse("hello this is fro separate url four")
